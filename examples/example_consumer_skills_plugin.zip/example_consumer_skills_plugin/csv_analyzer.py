"""
CSV Analyzer Plugin – example consumer of Agent Skills
=======================================================
This plugin demonstrates how any Grinning Cat plugin can:

1. Continue using @hook and @tool for traditional Python logic.
2. Add a `skills/` folder with SKILL.md-based skills, which the Agent Skills plugin will automatically load.

This example plugin declares a dependency on `agent_skills_plugin` in its
`plugin.json`, so skill discovery and activation are available as soon as both
plugins are active. The remaining convention is the folder structure.
"""

from cat import hook, StrayCat


@hook
def agent_prompt_prefix(prefix: str, cat: StrayCat) -> str:
    """Add a small hint about data analysis within the prefix."""
    return prefix + "\nYou are also a skilled data analyst.\n"
