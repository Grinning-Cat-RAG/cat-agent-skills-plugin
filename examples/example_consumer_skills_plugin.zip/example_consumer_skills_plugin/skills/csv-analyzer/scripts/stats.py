#!/usr/bin/env python3
"""
stats.py
========
Descriptive statistics for numeric columns in a CSV file.

Usage:
    python3 stats.py <filepath> [--columns col1,col2] [--encoding utf-8]
"""

import argparse
import json


def compute_stats(filepath: str, columns: list[str] | None, encoding: str) -> dict:
    try:
        import pandas as pd
    except ImportError:
        return {"error": "pandas not installed. Run: pip install pandas"}

    try:
        df = pd.read_csv(filepath, encoding=encoding)
    except Exception as exc:
        return {"error": str(exc)}

    if columns:
        missing = [c for c in columns if c not in df.columns]
        if missing:
            return {"error": f"Columns not found: {missing}. Available: {list(df.columns)}"}
        df = df[columns]

    numeric = df.select_dtypes(include="number")
    if numeric.empty:
        return {"error": "No numeric columns found", "columns": list(df.columns)}

    stats = numeric.describe().to_dict()
    # Add median explicitly (not in describe() by default for some pandas versions)
    for col in numeric.columns:
        stats[col]["median"] = float(numeric[col].median())

    return {
        "filepath": filepath,
        "analyzed_columns": list(numeric.columns),
        "statistics": stats,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Compute stats for a CSV file")
    parser.add_argument("filepath")
    parser.add_argument("--columns", help="Comma-separated column names", default=None)
    parser.add_argument("--encoding", default="utf-8")
    args = parser.parse_args()

    cols = [c.strip() for c in args.columns.split(",")] if args.columns else None
    result = compute_stats(args.filepath, cols, args.encoding)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
