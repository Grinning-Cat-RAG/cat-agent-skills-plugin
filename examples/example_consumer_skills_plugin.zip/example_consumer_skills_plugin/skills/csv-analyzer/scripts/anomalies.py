#!/usr/bin/env python3
"""
anomalies.py
============
Detect outliers in a numeric CSV column using the IQR method.

Usage:
    python3 anomalies.py <filepath> --column <col> [--encoding utf-8]
"""

import argparse
import json


def detect_anomalies(filepath: str, column: str, encoding: str) -> dict:
    try:
        import pandas as pd
    except ImportError:
        return {"error": "pandas not installed. Run: pip install pandas"}

    try:
        df = pd.read_csv(filepath, encoding=encoding)
    except Exception as exc:
        return {"error": str(exc)}

    if column not in df.columns:
        return {"error": f"Column '{column}' not found. Available: {list(df.columns)}"}

    series = df[column].dropna()
    if not pd.api.types.is_numeric_dtype(series):
        return {"error": f"Column '{column}' is not numeric (dtype: {series.dtype})"}

    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr

    outliers = df[(series < lower) | (series > upper)]

    return {
        "filepath": filepath,
        "column": column,
        "total_rows": len(series),
        "bounds": {"lower": float(lower), "upper": float(upper), "q1": float(q1), "q3": float(q3), "iqr": float(iqr)},
        "outlier_count": len(outliers),
        "outlier_rows": outliers.head(20).to_dict(orient="records"),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Detect outliers in a CSV column")
    parser.add_argument("filepath")
    parser.add_argument("--column", required=True)
    parser.add_argument("--encoding", default="utf-8")
    args = parser.parse_args()

    result = detect_anomalies(args.filepath, args.column, args.encoding)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
