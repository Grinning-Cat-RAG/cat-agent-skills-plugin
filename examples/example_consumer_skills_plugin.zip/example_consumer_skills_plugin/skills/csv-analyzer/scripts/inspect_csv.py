#!/usr/bin/env python3
"""
inspect_csv.py
==============
Quick inspection of a CSV file.
Returns a JSON summary: shape, columns, dtypes, null counts, preview rows.

Usage:
    python3 inspect_csv.py <filepath> [--encoding utf-8] [--no-header]
"""

import argparse
import json


def inspect(filepath: str, encoding: str = "utf-8", no_header: bool = False) -> dict:
    try:
        import pandas as pd
    except ImportError:
        return {"error": "pandas not installed. Run: pip install pandas"}

    header = None if no_header else "infer"
    try:
        df = pd.read_csv(filepath, encoding=encoding, header=header, nrows=1000)
    except UnicodeDecodeError:
        df = pd.read_csv(filepath, encoding="latin1", header=header, nrows=1000)
    except Exception as exc:
        return {"error": str(exc)}

    # Full shape requires reading all rows
    try:
        full_df = pd.read_csv(filepath, encoding=encoding, header=header)
        total_rows = len(full_df)
    except Exception:
        total_rows = len(df)

    return {
        "filepath": filepath,
        "shape": {"rows": total_rows, "columns": len(df.columns)},
        "columns": list(df.columns.astype(str)),
        "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
        "null_counts": df.isnull().sum().to_dict(),
        "preview": df.head(5).to_dict(orient="records"),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect a CSV file")
    parser.add_argument("filepath", help="Path to the CSV file")
    parser.add_argument("--encoding", default="utf-8", help="File encoding")
    parser.add_argument("--no-header", action="store_true", help="File has no header row")
    args = parser.parse_args()

    result = inspect(args.filepath, encoding=args.encoding, no_header=args.no_header)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
