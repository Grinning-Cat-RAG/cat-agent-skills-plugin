---
name: csv-analyzer
description: Analyzes CSV files to extract statistics, generate charts, detect anomalies, and produce summary reports. Use when the user uploads a CSV file, mentions spreadsheet data, asks for data analysis, or requests charts from tabular data.
license: GPL-3.0
compatibility: Requires Python 3.10+ with pandas and matplotlib installed
metadata:
  author: example-author
  version: "1.0"
  category: data-analysis
allowed-tools: Bash(python3:*) Read Write
---

# CSV Analyzer Skill

This skill provides a complete workflow for analyzing CSV data files within Grinning Cat.

## When to use this skill

Activate this skill when the user:
- Uploads or references a CSV or TSV file
- Asks for statistics, summaries, or insights from tabular data
- Requests charts or visualizations from data
- Mentions "spreadsheet", "dataset", "rows", "columns", or similar terms

## Workflow

### Step 1 – Load and inspect the file

Ask the user for the file path (or use the path from the uploaded file).

Run the inspection script to get a quick overview:
```
python3 scripts/inspect_csv.py <filepath>
```

This returns: shape, column names, dtypes, null counts, and a 5-row preview.

### Step 2 – Understand the user's goal

Ask (or infer from context) what the user wants:
- **Descriptive stats**: mean, median, std, min/max per numeric column
- **Distribution**: histogram for a specific column
- **Correlation**: heatmap of numeric columns
- **Anomalies**: outliers via IQR method
- **Export**: filtered or transformed CSV

### Step 3 – Execute the appropriate analysis

For descriptive stats:
```
python3 scripts/stats.py <filepath> [--columns col1,col2]
```

For anomaly detection:
```
python3 scripts/anomalies.py <filepath> --column <col>
```

### Step 4 – Present results

- Summarize findings in plain language.
- If a chart was generated, note its path and offer to describe it.
- Offer next steps (e.g., export filtered data, deeper analysis).

## Edge cases

- **Non-UTF-8 encoding**: try `--encoding latin1` flag on the scripts.
- **No header row**: pass `--no-header` flag; columns will be named col_0, col_1, …
- **Very large files (> 1M rows)**: scripts use chunked reading automatically.
- **Missing values**: reported in the inspection output; most scripts handle them gracefully.

## Reference material

See [references/data-analysis-guide.md](references/data-analysis-guide.md) for:
- Statistical concepts explained simply
- When to use which chart type
- How to interpret correlation values
