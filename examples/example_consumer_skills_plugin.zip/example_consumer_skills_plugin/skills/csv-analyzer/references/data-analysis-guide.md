# Data Analysis Reference Guide

A concise reference for the CSV Analyzer skill.

## Choosing the right analysis

| User wants                    | Use                             |
|-------------------------------|---------------------------------|
| Summary of the data           | `inspect_csv.py` + `stats.py`   |
| Find unusual values           | `anomalies.py`                  |
| Understand a distribution     | Ask for a histogram description |
| Relationships between columns | Ask for a correlation summary   |

## Interpreting statistics

### Mean vs median
- **Mean**: sum divided by count. Sensitive to outliers.
- **Median**: middle value. Better for skewed distributions.
- If mean >> median, the data is right-skewed (long tail of high values).
- If mean << median, the data is left-skewed.

### Standard deviation
- ~68% of values fall within ±1 std of the mean.
- ~95% fall within ±2 std.
- A large std relative to the mean suggests high variability.

### IQR (Interquartile Range)
- Q1 = 25th percentile, Q3 = 75th percentile.
- IQR = Q3 − Q1. Covers the middle 50% of the data.
- Outlier threshold: below Q1 − 1.5×IQR or above Q3 + 1.5×IQR.

## Correlation interpretation

| Value range     | Interpretation                  |
|-----------------|---------------------------------|
| 0.9 – 1.0       | Very strong positive            |
| 0.7 – 0.9       | Strong positive                 |
| 0.5 – 0.7       | Moderate positive               |
| 0.3 – 0.5       | Weak positive                   |
| -0.3 – 0.3      | Little or no linear correlation |
| Negative values | Same scale, inverse direction   |

## Common data quality issues

- **Missing values**: check `null_counts` in the inspect output. High null rates may indicate data collection problems.
- **Duplicate rows**: not currently detected by scripts; worth mentioning if shape is unexpected.
- **Mixed types in a column**: shows as `object` dtype. Consider asking the user whether the column should be numeric.
- **Date columns parsed as strings**: dtype will be `object`. Suggest the user confirm date formats.
